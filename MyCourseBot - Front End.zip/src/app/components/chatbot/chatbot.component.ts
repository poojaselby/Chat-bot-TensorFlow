import { Component, OnInit } from '@angular/core';
import { ChatbotService } from '../../services/chatbot.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})

export class ChatbotComponent implements OnInit {

  constructor(private chatbotService: ChatbotService) { }

  ngOnInit(): void {
  }

  apiLoading: boolean = false;
  chatInput = new FormControl();

  messages: any = [{
    userinput: 'Hi bot, how are you? How is the project coming along?',
    chatresponse: 'Are we meeting today? Project has been already finished and I have results to show you.'
  }];

  sendChat() {
    this.apiLoading = true;
    this.chatbotService.getChatBotResponse(this.chatInput.value).subscribe((response: any) => {
      if (response) {
      //this.chatInput.reset();

        this.messages.push({ userinput: this.chatInput.value, chatresponse: response });
      }
      else {
        this.messages.push({ userinput: this.chatInput.value, chatresponse: 'Sorry, I am not able to understand your query. Please retrain me!' });
      }
      this.apiLoading = false;
    }, (error: any) => {
      this.messages.push({ userinput: this.chatInput.value, chatresponse: 'Sorry, I am not able to understand your query. Please retrain me!' });
      this.apiLoading = false;
    })
  }

}
