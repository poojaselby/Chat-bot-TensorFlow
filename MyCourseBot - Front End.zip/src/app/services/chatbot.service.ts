import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { API_BASE_URL } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {

  constructor(private http: HttpClient) { }

  getChatBotResponse(keyword: any) {
    const params = new HttpParams().set('msg', keyword);
    const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
          })
        };
    return this.http.post(`http://127.0.0.1:5000/get`, params, httpOptions);
  }

}
